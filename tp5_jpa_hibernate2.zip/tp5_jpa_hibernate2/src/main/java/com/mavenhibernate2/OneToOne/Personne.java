package com.mavenhibernate2.OneToOne;

import javax.persistence.*;


@Entity
@Table(name="personne")

public class Personne {
	   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long personne_id;
	private String nom;
	private String prenom;
	private int naissance;
	
	//D�finir une relation un-�-un avec Professeur
	//mappedBy = "personne" signifie que le c�t� ma�tre de la relation (celui qui poss�de la cl� �trang�re) est Professeur.
	@OneToOne(mappedBy = "personne")
	private Professeur prof;

	public Personne() {
		super();
	}   
	public long getPersonne_id() {
		return this.personne_id;
	}

	public void setPersonne_id(long personne_id) {
		this.personne_id = personne_id;
	}   
	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}   
	public String getPrenom() {
		return this.prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}   
	public int getNaissance() {
		return this.naissance;
	}

	public void setNaissance(int naissance) {
		this.naissance = naissance;
	}
	public Professeur getProf() {
		return prof;
	}
	public void setProf(Professeur prof) {
		this.prof = prof;
	}
   
	
}
