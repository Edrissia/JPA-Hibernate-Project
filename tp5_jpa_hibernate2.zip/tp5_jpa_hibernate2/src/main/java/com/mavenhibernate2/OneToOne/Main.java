package com.mavenhibernate2.OneToOne;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {

		
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("tp5_jpa_hibernate2");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        Personne personne = new Personne();
        personne.setNom("RIDA");
        personne.setPrenom("Edrissia");
        personne.setNaissance(2003);

        Professeur professeur = new Professeur();
        professeur.setMatiere("Mathematiques");
        professeur.setPersonne(personne);

        //Association entre les entit�s
        personne.setProf(professeur);

        // Persist the `professeur` first
        em.persist(professeur);
        // Then persist the `personne`
        em.persist(personne);
        
		System.out.println("Verifier votre base de donnees");

        em.getTransaction().commit();
        em.close();
        emf.close();
	}

}
