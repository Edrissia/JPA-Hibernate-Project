package com.mavenhibernate2.OneToMany_ManyToOne;

import javax.persistence.*;

public class Main {

	public static void main(String[] args) {
		
	    // Cr�er une EntityManagerFactory pour g�rer les entit�s
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("tp5_jpa_hibernate2");
        EntityManager em = emf.createEntityManager();

        // D�but de la transaction
        em.getTransaction().begin();

        // Cr�ation d'une adresse
        Adresse adresse = new Adresse();
        adresse.setRue("FPSB");
        adresse.setCodePostal("24000");
        adresse.setVille("Casablanca");

        // Cr�ation des d�partements associ�s � l'adresse
        Departement dep1 = new Departement();
        dep1.setNom("Mathematique");
        dep1.setAdresse(adresse);

        Departement dep2 = new Departement();
        dep2.setNom("Informatique");
        dep2.setAdresse(adresse);

        Departement dep3 = new Departement();
        dep3.setNom("Physique");
        dep3.setAdresse(adresse);

        // Ajouter les d�partements � la liste de l'adresse
        adresse.getDepartements().add(dep1);
        adresse.getDepartements().add(dep2);
        adresse.getDepartements().add(dep3);

        // Sauvegarder l'adresse et les d�partements dans la base de donn�es
        
        em.persist(adresse);

        // Validation de la transaction
        em.getTransaction().commit();
        
        // Fermer l'EntityManager et l'EntityManagerFactory
        em.close();
        emf.close();

        System.out.println("Donnees enregistrees avec succees !");
	}

}
