package com.mavenhibernate2.ManyToMany;

import javax.persistence.*;

public class Main {

	public static void main(String[] args) {
		// Cr�er une EntityManagerFactory pour g�rer les entit�s
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("tp5_jpa_hibernate2");
        EntityManager em = emf.createEntityManager();

        // D�but de la transaction
        em.getTransaction().begin();
     
        // Cr�ation des modules
        Module module1 = new Module();
        module1.setNom("Mathematiques");

        Module module2 = new Module();
        module2.setNom("Informatique");

        Module module3 = new Module();
        module3.setNom("Physique");

        // Cr�ation des �tudiants
        Etudiant etudiant1 = new Etudiant();
        etudiant1.setNom("RIDA");
        etudiant1.setPrenom("Edrissia");
        etudiant1.setCne("CNE12345");

        Etudiant etudiant2 = new Etudiant();
        etudiant2.setNom("rida");
        etudiant2.setPrenom("nour");
        etudiant2.setCne("CNE6789");

        // Association des �tudiants avec les modules
        etudiant1.getModules().add(module1);
        etudiant1.getModules().add(module2);

        etudiant2.getModules().add(module2);
        etudiant2.getModules().add(module3);

        module1.getEtudiants().add(etudiant1);
        module2.getEtudiants().add(etudiant1);
        module2.getEtudiants().add(etudiant2);
        module3.getEtudiants().add(etudiant2);

        // Persister les entit�s dans la base de donn�es
        em.persist(module1);
        em.persist(module2);
        em.persist(module3);
        em.persist(etudiant1);
        em.persist(etudiant2);

        // Validation de la transaction
        em.getTransaction().commit();
        
        // Fermer l'EntityManager et l'EntityManagerFactory
        em.close();
        emf.close();

        System.out.println("Donnees enregistrees avec succees !");
		
	}

}
