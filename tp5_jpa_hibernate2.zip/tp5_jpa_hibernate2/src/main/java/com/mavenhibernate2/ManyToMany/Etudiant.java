package com.mavenhibernate2.ManyToMany;


import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="etudiant")

public class Etudiant{

	   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long etudiant_id;
	private String nom;
	private String prenom;
	private String cne;
	
	@ManyToMany
	@JoinTable(
	        name = "etudiant_module",
	        joinColumns = @JoinColumn(name = "etudiant_id"),
	        inverseJoinColumns = @JoinColumn(name = "module_id")
	      )
	private List<Module> modules = new ArrayList<Module>();

	public Etudiant() {
		super();
	}   
	public long getEtudiant_id() {
		return this.etudiant_id;
	}

	public void setEtudiant_id(long etudiant_id) {
		this.etudiant_id = etudiant_id;
	}   
	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}   
	public String getPrenom() {
		return this.prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}   
	public String getCne() {
		return this.cne;
	}

	public void setCne(String cne) {
		this.cne = cne;
	}
	
	public List<Module> getModules() {
        return modules;
    }

    public void setModules(List<Module> modules) {
        this.modules = modules;
    }
   
}
